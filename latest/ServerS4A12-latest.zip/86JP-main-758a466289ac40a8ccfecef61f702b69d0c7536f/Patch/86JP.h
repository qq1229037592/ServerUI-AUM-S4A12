#pragma once

void JPEntry();
